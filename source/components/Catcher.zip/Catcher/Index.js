// Core
import React, { Component } from 'react';

//Instruments
import { object } from 'prop-types';
import Styles from './styles.m.css';

export default class Catcher extends Component {
    static propTypes = {
        children: object.isRequired,
    };

    state = {
        error: false,
    };

    componentDidCatch (error, stack) {
        console.log('ERROR:', error);
        console.log('STACKTRACE:', stack.componentStack);

        this.setState({
            error: true,
        });
    };

    render() {
        console.log('--> catcher');

        if (this.state.error) {

            return (
                <section className = { Styles.catcher }>
                    <div id="clouds">
                        <div className = { Styles.cloud_x1 }></div>
                        <div className = { Styles.cloud_x1_5 }></div>
                        <div className = { Styles.cloud_x2 }></div>
                        <div className = { Styles.cloud_x3 }></div>
                        <div className = { Styles.cloud_x4 }></div>
                        <div className = { Styles.cloud_x5 }></div>
                    </div>
                    <div className = { Styles.c }>
                        <div className = { Styles._404 }>404</div>
                        <hr/>
                        <div className = { Styles._1 }>THE PAGE</div>
                        <div className = { Styles._2 }>WAS NOT FOUND</div>
                        <a className = { Styles.btn } href='#'>BACK TO MARS</a>
                        
                    </div>
                </section>
            );
        }

        return this.props.children;
    }
}